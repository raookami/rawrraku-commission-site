import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getStatusStyle } from '../themes';
import ReviewMarquee from '../komponen/ReviewMarquee';
import { supabase } from '../supabase';

export default function Home({ isDark, theme, isAdmin }) {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(true);
  const [info, setInfo] = useState({
    hero_desc: 'specialize in cute male character design.',
    info_estimasi: '7–14 hari kerja',
    info_pembayaran: 'Transfer Bank / E-WALLET',
    info_revisi: '2x revisi minor',
    info_format: 'PNG / JPG 300dpi',
  });

  useEffect(() => {
    async function fetchSettings() {
      const { data } = await supabase.from('settings').select('key, value');
      if (data && data.length > 0) {
        const map = {};
        data.forEach((s) => { map[s.key] = s.value; });
        setInfo((prev) => ({ ...prev, ...map }));
        if (map.commission_open !== undefined) {
          setIsOpen(map.commission_open === 'true');
        }
      }
    }
    fetchSettings();
  }, []);

  return (
    <div className="page-enter">
      <ReviewMarquee
        isDark={isDark}
        onClickReviews={() => navigate('/reviews')}
      />

      <div style={theme.page}>
        {/* Hero */}
        <div style={theme.hero}>
          <img
            src="/lv_0_20250116221257.gif"
            alt="Raooraku"
            style={{ width: 100, height: 100, borderRadius: '100%', objectFit: 'cover' }}
          />
          <h2 style={theme.heroTitle}>HI! I'M RAOORAKU ✨</h2>
          <p style={theme.heroDesc}>{info.hero_desc}</p>
          <div style={theme.heroButtons}>
            <button style={theme.btnPrimary} onClick={() => navigate('/commission')}>IDR COMMISSION</button>
            <button style={theme.btnSecondary} onClick={() => navigate('/portfolio')}>PORTFOLIO</button>
            <button style={theme.btnSecondary} onClick={() => window.open('https://vgen.co/raooraku_', '_blank')}>USD COMMISSION ↗</button>
          </div>
        </div>

        {/* Status commission */}
        <div style={{ ...theme.statusBox, ...getStatusStyle(isOpen, isDark), color: isOpen ? '#5ed15e' : '#ca5b5b' }}>
          <span style={{ ...theme.statusDot, background: isOpen ? '#0c0' : '#e00' }} />
          <strong>{isOpen ? 'COMMISSION OPEN' : 'COMMISSION CLOSED'}</strong>
          <button
            onClick={async () => {
              if (!isAdmin) return;
              const newStatus = !isOpen;
              setIsOpen(newStatus);
              await supabase.from('settings').upsert({ key: 'commission_open', value: String(newStatus) }, { onConflict: 'key' });
            }}
            style={{ marginLeft: 'auto', padding: '4px 14px', borderRadius: 999, border: 'none', background: isAdmin ? (isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.06)') : 'transparent', cursor: isAdmin ? 'pointer' : 'default', fontSize: 12, color: isAdmin ? (isDark ? '#ccc' : '#555') : 'transparent' }}
          >
            {isAdmin ? (isOpen ? 'Tutup' : 'Buka') : ''}
          </button>
        </div>

        {/* Info singkat — dari database */}
        <div style={theme.infoGrid}>
          {[
            { icon: '⏱️', label: 'Estimasi', value: info.info_estimasi },
            { icon: '💳', label: 'Pembayaran', value: info.info_pembayaran },
            { icon: '🔄', label: 'Revisi', value: info.info_revisi },
            { icon: '📩', label: 'Format', value: info.info_format },
          ].map((item) => (
            <div key={item.label} style={theme.infoCard}>
              <div style={theme.infoIcon}>{item.icon}</div>
              <div style={theme.infoLabel}>{item.label}</div>
              <div style={theme.infoValue}>{item.value}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
